<?php 
	$con = mysqli_connect('localhost','root','','simpleave');
	if (!$con) {
		echo "Database Not Connected";
	}
 ?>